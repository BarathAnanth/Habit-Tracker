import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const habit = {
  id: "",
  name: "",
  frequency: "",
  completedDates: [],
  createdAt: "",
};

const initialState = {
  habits: [],
  isLoading: false,
  error: null,
};

export const fetchHabit = createAsyncThunk("habits/fetchHabits", async () => {
  //Simulating an API call
  await new Promise((resolve) => setTimeout(resolve, 1000));
  const mockHabits = [
    {
      id: "1",
      name: "Read a book",
      frequency: "daily",
      completedDates: [],
      createdAt: new Date().toISOString(),
    },
    {
      id: "2",
      name: "Exercise",
      frequency: "daily",
      completedDates: [],
      createdAt: new Date().toISOString(),
    },
  ];
  return mockHabits;
});

const habitSlice = createSlice({
  name: "habits",
  initialState,
  reducers: {
    addHabit(state, action) {
      console.log(action);
      const newHabit = {
        id: Date.now().toString(),
        name: action.payload.name,
        frequency: action.payload.frequency,
        completedDates: [],
        createdAt: new Date().toISOString(),
      };
      state.habits.push(newHabit);
    },
    toggleHabit(state, action) {
      const habit = state.habits.find((h) => h.id === action.payload.id);
      if (habit) {
        const index = habit.completedDates.indexOf(action.payload.date);
        if (index > -1) {
          habit.completedDates.splice(index, 1);
        } else {
          habit.completedDates.push(action.payload.date);
        }
      }
    },
    removeHabit(state, action) {
      const habitIndex = state.habits.findIndex(
        (h) => h.id === action.payload.id
      );
      if (habitIndex > -1) {
        state.habits.splice(habitIndex, 1);
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchHabit.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchHabit.fulfilled, (state, action) => {
        state.isLoading = false;
        state.habits = action.payload;
      })
      .addCase(fetchHabit.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message || "Failed to fetch habits";
      });
  },
});

export const { addHabit, toggleHabit, removeHabit } = habitSlice.actions;
export const habitReducer = habitSlice.reducer;
export default habitReducer;
